package com.example.kitchenerp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class KitchenItem(val name:String,val category:String,val quantity:Int,val unit:String,val location:String,val detail:String="")

class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{KitchenERPApp()}}}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun KitchenERPApp(){
 var items by remember { mutableStateOf(listOf(
  KitchenItem("12cm 공기","식기 / 그릇류",6,"개","주방 / 상부장","도기"),
  KitchenItem("냄비","조리도구 / 냄비류",2,"개","주방 / 하부장","3L · 인덕션 가능")
 ))}
 var show by remember{mutableStateOf(false)}; var q by remember{mutableStateOf("")}
 MaterialTheme{Scaffold(topBar={TopAppBar(title={Text("주방 ERP")})},floatingActionButton={FloatingActionButton(onClick={show=true}){Text("+")}}){p->
  Column(Modifier.padding(p).padding(16.dp).fillMaxSize()){
   OutlinedTextField(q,{q=it},Modifier.fillMaxWidth(),label={Text("물건 검색")},singleLine=true)
   Spacer(Modifier.height(16.dp)); Text("전체 물건 ${items.size}개",style=MaterialTheme.typography.titleMedium); Spacer(Modifier.height(8.dp))
   LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(items.filter{q.isBlank()||it.name.contains(q,true)||it.category.contains(q,true)||it.location.contains(q,true)}){x->ElevatedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(x.name,style=MaterialTheme.typography.titleLarge);Text("${x.category} · ${x.quantity}${x.unit}");Text(x.location);if(x.detail.isNotBlank())Text(x.detail)}}}}
  }
 }
 if(show)RegisterDialog({show=false}){items=items+it;show=false}
 }}

@Composable fun RegisterDialog(onDismiss:()->Unit,onSave:(KitchenItem)->Unit){
 var name by remember{mutableStateOf("")};var category by remember{mutableStateOf("식기")};var qty by remember{mutableStateOf("1")};var loc by remember{mutableStateOf("주방")};var detail by remember{mutableStateOf("")}
 AlertDialog(onDismissRequest=onDismiss,title={Text("물건 등록")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
  OutlinedTextField(name,{name=it},label={Text("품목명")},singleLine=true);OutlinedTextField(category,{category=it},label={Text("분류")},singleLine=true);OutlinedTextField(qty,{qty=it},label={Text("수량")},singleLine=true);OutlinedTextField(loc,{loc=it},label={Text("위치")},singleLine=true);OutlinedTextField(detail,{detail=it},label={Text("특성 / 추가정보")})
 }},confirmButton={TextButton(enabled=name.isNotBlank(),onClick={onSave(KitchenItem(name.trim(),category.trim(),qty.toIntOrNull()?:1,"개",loc.trim(),detail.trim()))}){Text("저장")}},dismissButton={TextButton(onClick=onDismiss){Text("취소")}})
}
